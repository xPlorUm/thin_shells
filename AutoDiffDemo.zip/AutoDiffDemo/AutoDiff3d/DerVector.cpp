// CVS ID
// $Id: DerVector.cpp,v 1.4 2003/09/18 22:17:16 eitan Exp $

// AUTHOR
// Eitan Grinspun

// CONTACT
// email:eitan[at]cs[dot]caltech[dot]edu, email:eitan[at]cat[dot]nyu[dot]edu

// DESCRIPTION
// This file implements the class DerVector. This class represents vectors
// that are dependent on other variables, ie, such vectors are represented
// a vector/matrix tuple carrying the value and derivative respectively.

#include <math.h>

#include "Matrix.h"
#include "Vector.h"
#include "Scalar.h"

#include "ConstScalar.h"
#include "DerScalar.h"
#include "DerVector.h"

DerVector::DerVector(void) {
}

DerVector::~DerVector(void) {
}


DerVector::DerVector( const Vector& v, const Matrix& D ) 
  : m_v( v ), m_D( D ) {}



// computes the vector norm and its derivative
// uses the chain rule: D(norm(x)) = (D norm)(x) (Dx)
DerScalar DerVector::Length( void ) const {

  const Vector& x  = v();
  const Matrix& Dx = D();

  return DerScalar( x.Length(),
		    DiffLength(x) * Dx );
}


// computes the vector negation and its derivative
DerVector DerVector::operator- ( void ) const {

  const Vector& x  = v();
  const Matrix& Dx = D();

  return DerVector( -x, -Dx);
}


// computes the vector-vector sum and its derivative
DerVector DerVector::operator+ ( const Vector& v2 ) const {

  const Vector& x  = v();
  const Matrix& Dx = D();

  const Vector& y = v2;
  
  return DerVector( x + y, Dx );
}


// computes the vector-vector sum and its derivative
DerVector DerVector::operator+ ( const DerVector& Tv2 ) const {

  const Vector& x = v();
  const Matrix& Dx = D();

  const Vector& y = Tv2.v();
  const Matrix& Dy = Tv2.D();

  return DerVector( (x + y), (Dx + Dy) );
}


// computes the vector-vector difference and its derivative
DerVector DerVector::operator- ( const Vector& v2 ) const {

  const Vector& x  = v();
  const Matrix& Dx = D();

  const Vector& y = v2;
  
  return DerVector( x - y, Dx );
}


// computes the vector-vector difference and its derivative
DerVector DerVector::operator- ( const DerVector& Tv2 ) const {

  const Vector& x  = v();
  const Matrix& Dx = D();

  const Vector& y  = Tv2.v();
  const Matrix& Dy = Tv2.D();

  return DerVector( (x - y), (Dx - Dy) );
}


// computes dot product and its derivative
// uses chain rule: D(a.b) = b(Da)  where b is a constant, (Db)=0
DerScalar DerVector::Dot( const Vector& v2 ) const {

  const Vector& x = v();
  const Matrix& Dx = D();

  const Vector& y = v2;

  return DerScalar( x. Dot( y ),
	            y*Dx );
}


// computes dot product and its derivative
// uses chain rule: D(a.b) = a(Db) + b(Da)
DerScalar DerVector::Dot( const DerVector& Tv2 ) const {

  const Vector& x = v();
  const Matrix& Dx = D();

  const Vector& y = Tv2.v();
  const Matrix& Dy = Tv2.D();

  return DerScalar( x. Dot( y ),
		    x*Dy + y*Dx );
}


Vector DerVector::DiffLength( const Vector& x ) const {

  Scalar n2 = x. Dot( x );

  if (n2 == 0) return x; // d/dx ||0-vector|| = 0-vector

  else return pow((double)n2, -0.5) * x;
}



// computes the vector-vector sum and its derivative
DerVector operator+ ( const Vector& v1, const DerVector& Tv2 ) {

  const Vector& x1 = v1;
  const Vector& x2 = Tv2.v();
  const Matrix& D2 = Tv2.D();
 
  return DerVector( x1 + x2, D2);
}


// computes the vector-vector difference and its derivative
DerVector operator- ( const Vector& v1, const DerVector& Tv2 ) {

  const Vector& x1 = v1;
  const Vector& x2 = Tv2.v();
  const Matrix& D2 = Tv2.D();
 
  return DerVector( x1 - x2, -D2);
}


// computes the vector-vector (scalar-valued) dot product
// and its derivative
// uses chain rule: D(a.b) = a(Db) when a is constant, ie, (Da)=0
DerScalar Dot( const Vector& v1, const DerVector& Tv2 ) {

  const Vector& x1 = v1;
  const Vector& x2 = Tv2.v();
  const Matrix& D2 = Tv2.D();

  return DerScalar( x1. Dot( x2), x1 * D2 );
}


// returns eps_ijk
int Eps(int i, int j, int k)
{
	if (i == 0 && j == 1 && k == 2) return +1;
	if (i == 1 && j == 2 && k == 0) return +1;
	if (i == 2 && j == 0 && k == 1) return +1;

	if (i == 0 && k == 1 && j == 2) return -1;
	if (i == 1 && k == 2 && j == 0) return -1;
	if (i == 2 && k == 0 && j == 1) return -1;

	return 0;
}


// returns the (matrix) derivative of the cross product w.r.t. its 1st argument, D1 cross(.,.)
// computed as ESN: (D1 cross(.,.))(A,B)_ij := eps_ijk b_k
Matrix DiffCross1(Vector , Vector y) {

  Matrix result;
  for (int i = 0; i < 3; ++i)
    for (int j = 0; j < 3; ++j) {
      result[i][j] = 0;
      for (int k = 0; k < 3; ++k) {
	result[i][j] += Eps(i,j,k) * y[k];
      }
    }
  return result;
}


// returns the (matrix) derivative of the cross product w.r.t. its 2d argument, D2 cross(.,.)
// computed as ESN: (D2 cross(.,.))(A,B)_ij := eps_ikj a_k
Matrix DiffCross2(Vector x, Vector ) {

  Matrix result;
  for (int i = 0; i < 3; ++i)
    for (int j = 0; j < 3; ++j) {
      result[i][j] = 0;
      for (int k = 0; k < 3; ++k) {
	result[i][j] += Eps(i,k,j) * x[k];
      }
    }
  return result;
}


// computes the vector-vector (vector-valued) cross product
// and its derivative
// uses chain rule: D(a x b) = D2(a x b)(Db), a is a constant, (Da)=0
DerVector Cross( const Vector& v1, const DerVector& Tv2 ) {

  const Vector& x1 = v1;
  const Vector& x2 = Tv2.v();
  const Matrix& D2 = Tv2.D();

  return DerVector( x1. Cross( x2 ), DiffCross2(x1,x2) * D2);
}


// computes cross product and its derivative
// uses chain rule: D(a x b) = Dx(a x b)(Da) + Dy(a x b)(Db)
DerVector DerVector::Cross( const DerVector& Tv2 ) const {

  const Vector& x = v();
  const Matrix& Dx = D();

  const Vector& y = Tv2.v();
  const Matrix& Dy = Tv2.D();

  return DerVector( x. Cross( y ),
		    DiffCross1(x,y) * Dx + DiffCross2(x,y) * Dy );
}

// computes cross product and its derivative
// uses chain rule: D(a x b) = Dx(a x b)(Da), b is constant, (Db)=0
DerVector DerVector::Cross( const Vector& v2 ) const {

  const Vector& x = v();
  const Matrix& Dx = D();

  const Vector& y = v2;

  return DerVector( x. Cross( y ),
		    DiffCross1(x,y) * Dx );
}
