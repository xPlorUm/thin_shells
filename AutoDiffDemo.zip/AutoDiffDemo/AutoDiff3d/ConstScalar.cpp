// CVS ID
// $Id: ConstScalar.cpp,v 1.2 2003/09/18 20:11:52 eitan Exp $

// AUTHOR
// Eitan Grinspun

// CONTACT
// email:eitan[at]cs[dot]caltech[dot]edu, email:eitan[at]cat[dot]nyu[dot]edu

// DESCRIPTION
// This file implements the class ConstScalar. This class represents scalar values
// that are independent variables, ie, such values need not carry
// derivative information, as their derivative w.r.t. any other independent
// variable is 0.

#include <math.h>

#include "Matrix.h"
#include "Vector.h"
#include "Scalar.h"

#include "ConstScalar.h"
#include "DerScalar.h"
#include "DerVector.h"


// constructor (does not clear the value!)
ConstScalar::ConstScalar(void) {}


// destructor
ConstScalar::~ConstScalar(void) {}


// computes the scalar negation
ConstScalar ConstScalar::operator- ( void ) const {

  const Scalar& a = v();

  return ConstScalar( -a );
}


// computes the scalar-inverse
ConstScalar ConstScalar::Inv( void ) const {

  const Scalar& a = v();

  return ConstScalar( 1./a );
}


// computes the scalar-square-root
ConstScalar ConstScalar::Sqrt( void ) const {

  const Scalar& a = v();

  return ConstScalar( sqrt(a) );
}


// computes the scalar-scalar sum
ConstScalar ConstScalar::operator+ ( const ConstScalar& Tb ) const {

  const Scalar& a = v();
  const Scalar& b = Tb.v();

  return ConstScalar( a + b );
}


// computes the scalar-scalar sum and its derivative
DerScalar ConstScalar::operator+ ( const DerScalar& Tb ) const {

  const Scalar& a = v();

  const Scalar& b  = Tb.v();
  const Vector& Db = Tb.D();

  return DerScalar( a + b, Db );
}


// computes the scalar-scalar difference
ConstScalar ConstScalar::operator- ( const ConstScalar& Tb ) const {

  const Scalar& a = v();
  const Scalar& b = Tb.v();

  return ConstScalar( a - b );
}


// computes the scalar-scalar difference and its derivative
DerScalar ConstScalar::operator- ( const DerScalar& Tb ) const {

  const Scalar& a = v();

  const Scalar& b  = Tb.v();
  const Vector& Db = Tb.D();

  return DerScalar( a - b, -Db );
}


// computes the scalar-scalar product
ConstScalar ConstScalar::operator* ( const ConstScalar& Tb ) const {

  const Scalar& a = v();
  const Scalar& b = Tb.v();

  return ConstScalar( a * b );
}


// computes the scalar-scalar product and its derivative
// since a is a constant, D(ab) = a(Db)
DerScalar ConstScalar::operator* ( const DerScalar& Tb ) const {

  const Scalar& a = v();

  const Scalar& b  = Tb.v();
  const Vector& Db = Tb.D();

  return DerScalar( a * b, a * Db );
}


// computes the scalar-scalar quotient
ConstScalar ConstScalar::operator/ ( const ConstScalar& Cb ) const {

  const Scalar& a = v();
  const Scalar& b = Cb.v();

  return ConstScalar( a / b );
}


// computes scalar-vector product
Vector ConstScalar::operator* ( const Vector& Cv ) const {

  const Scalar& a = v();

  const Vector& x  = Cv;

  return Vector( a * x );
}


// computes scalar-vector product and its derivative
// since a is a constant, D(av) = a(Dv)
DerVector ConstScalar::operator* ( const DerVector& Tx ) const {

  const Scalar& a = v();

  const Vector& x  = Tx.v();
  const Matrix& Dx = Tx.D();

  return DerVector( a * x, a * Dx );
}


ConstScalar atan2( ConstScalar Ca, ConstScalar Cb ) {

  const Scalar& a = Ca.v();
  const Scalar& b = Cb.v();

  return ConstScalar( atan2( a, b));
}


// can't afford to have sign zero, as it sometimes leads to unfortunate
// and unexpected zero derivatives
// => therefore, zero is (defined to be) positive
ConstScalar sign( ConstScalar Ca ) {

  const Scalar& a = Ca.v();
  if (a < 0) return ConstScalar( -1 );
  else return ConstScalar( +1 );
}
