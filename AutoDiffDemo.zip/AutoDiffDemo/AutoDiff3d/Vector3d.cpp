// vim:ts=2 sw=2

/// \file   Vector3d.cpp
/// \brief  Implementation of the Vector3d class

//********************************************
// mmeyer@gg.caltech.edu
// Created :  09/07/00
//
// ajsecord at cs dot nyu dot edu
// Modified : 09/24/03
//********************************************

#include "Vector3d.h"

#include <cmath>
#include <cstdio>
#include <iostream>

#ifndef PI
#define PI 3.14159
#endif

Vector3d Vector3d::Zero(0, 0, 0);

Vector3d Vector3d::BaryAverage(const Vector3d& b, const Vector3d v[3]) {
  Vector3d result = Zero;
  for (int i = 0; i < 3; ++i) 
    result += b[i] * v[i];

  return result;
}

//////////////////////////////////////////////
// CONSTRUCTORS
//////////////////////////////////////////////

/*
Vector3d::Vector3d( const CalVector& v ) { 
  _vec[0] = v[0]; 
  _vec[1] = v[1]; 
  _vec[2] = v[2];
}
*/

//////////////////////////////////////////////
// OPERATORS
//////////////////////////////////////////////

Vector3d& Vector3d::operator+=(const Vector3d& rVector) {
  _vec[0] += rVector.x();
  _vec[1] += rVector.y();
  _vec[2] += rVector.z();
  return *this;
}

Vector3d& Vector3d::operator+=(const Vector3d* pVector) {
  _vec[0] += pVector->x();
  _vec[1] += pVector->y();
  _vec[2] += pVector->z();
  return *this;
}

Vector3d& Vector3d::operator-=(const Vector3d& rVector) {
  _vec[0] -= rVector.x();
  _vec[1] -= rVector.y();
  _vec[2] -= rVector.z();
  return *this;
}

Vector3d& Vector3d::operator-=(const Vector3d* pVector) {
  _vec[0] -= pVector->x();
  _vec[1] -= pVector->y();
  _vec[2] -= pVector->z();
  return *this;
}

Vector3d& Vector3d::operator*=(Scalar d) {
  _vec[0] *= d;
  _vec[1] *= d;
  _vec[2] *= d;
  return *this;
}

/// Nondestructive unary minus.  Returns a new vector.
Vector3d Vector3d::operator -() const {
  return Vector3d( -_vec[0], -_vec[1], -_vec[2]);
}

Vector3d operator+(const Vector3d& u, const Vector3d& v) {
  return Vector3d(u._vec[0] + v._vec[0], u._vec[1] + v._vec[1], u._vec[2] + v._vec[2]);
}

Vector3d operator-(const Vector3d& u, const Vector3d& v) {
  return Vector3d(u._vec[0] - v._vec[0], u._vec[1] - v._vec[1], u._vec[2] - v._vec[2]);
}

Vector3d operator*(const Scalar s, const Vector3d& u) {
  return Vector3d(u._vec[0] * s, u._vec[1] * s, u._vec[2] * s);
}

/// Returns the cross product of u and v.
Vector3d Cross(const Vector3d& u, const Vector3d& v) {
  return Vector3d(u._vec[1] * v._vec[2] - u._vec[2] * v._vec[1],
                  u._vec[2] * v._vec[0] - u._vec[0] * v._vec[2],
                  u._vec[0] * v._vec[1] - u._vec[1] * v._vec[0]);
}

/// Dot product of u and v
Scalar Dot(const Vector3d& u, const Vector3d& v) {
  return u._vec[0] * v._vec[0] +
         u._vec[1] * v._vec[1] +
         u._vec[2] * v._vec[2];
}

int operator==(const Vector3d& v1, const Vector3d& v2) {
  return (v1._vec[0] == v2._vec[0] &&
          v1._vec[1] == v2._vec[1] &&
          v1._vec[2] == v2._vec[2]);
}

/// Determines if two vectors are equal within a tolerence (squared distance).
bool Vector3d::Equals(const Vector3d& v, const Scalar eps) const {
  return (*this - v).LengthSquared() <= eps;
}


Vector3d Vector3d::Cross(const Vector3d& v) const {
  return Vector3d(y() * v.z() - z() * v.y(),
                  z() * v.x() - x() * v.z(),
                  x() * v.y() - y() * v.x());
}

Vector3d Vector3d::Cross(const Vector3d* pV) const {
  return Vector3d(y() * pV->z() - z() * pV->y(),
                  z() * pV->x() - x() * pV->z(),
                  x() * pV->y() - y() * pV->x());
}

Scalar Vector3d::Normalize() {
  Scalar len = Length();
  if (len != 0.0f)
    (*this) *= (1.0 / len);
  else
    Set(0.f, 0.f, 0.f);

  return len;
}

Scalar Vector3d::Normalize(Scalar value) {
  Scalar len = Length();
  if (len != 0.0f)
    (*this) *= (value / len);
  else
    Set(0.f, 0.f, 0.f);

  return len;
}

Scalar Vector3d::LengthSquared() const {
  return (Scalar)_vec[0] * (Scalar)_vec[0] +
         (Scalar)_vec[1] * (Scalar)_vec[1] +
         (Scalar)_vec[2] * (Scalar)_vec[2];
}

Scalar Vector3d::Length() const {
  return sqrt((Scalar)_vec[0]*(Scalar)_vec[0] +
              (Scalar)_vec[1]*(Scalar)_vec[1] +
              (Scalar)_vec[2]*(Scalar)_vec[2] );
}

int Vector3d::IsCollinear(Vector3d *pVector) const {
  Scalar x = pVector->x() / _vec[0];
  Scalar y = pVector->y() / _vec[1];
  Scalar z = pVector->z() / _vec[2];
  return ((x == y) && (y == z));
}

int Vector3d::IsCollinear(Vector3d &vector) const {
  Scalar x = vector.x() / _vec[0];
  Scalar y = vector.y() / _vec[1];
  Scalar z = vector.z() / _vec[2];
  return ((x == y) && (y == z));
}

void Vector3d::Negate() {
  _vec[0] = -_vec[0];
  _vec[1] = -_vec[1];
  _vec[2] = -_vec[2];
}

/// Rotate this vector around the vector around by angle radians.
/// By Haeyoung Lee.
Vector3d Vector3d::Rotate(Scalar angle, Vector3d around) {
  const Scalar f1 = cos(angle);
  const Scalar f2 = sin(angle);

  Vector3d t1, t2;
  t1 = Projection(&around);
  t2 = around.Cross(this);
  const Scalar f3 = Dot(around);

  return Vector3d(
           (Scalar)(f1 * t1.x() + f2 * t2.x() + f3 * around.x()),
           (Scalar)(f1 * t1.y() + f2 * t2.y() + f3 * around.y()),
           (Scalar)(f1 * t1.z() + f2 * t2.z() + f3 * around.z()));
}

/// Projection.  By Haeyoung Lee.
Vector3d Vector3d::Projection(const Vector3d* pV) const {
  const Scalar alpha = Dot(pV) / pV->Dot(pV);
  return Vector3d(x() - alpha * pV->x(),
                  y() - alpha * pV->y(),
                  z() - alpha * pV->z());
}

//**************************************
// Angle between two vectors (in radians)
// we use this formula
// uv = |u||v| cos(u,v)
// u  ^ v  = w
// |w| = |u||v| |sin(u,v)|
//**************************************
Scalar Vector3d::Angle(const Vector3d& u, const Vector3d& v) {
  Scalar NormU = u.Length ();
  Scalar NormV = v.Length ();
  Scalar product = NormU * NormV;

  // Check
  if (product == 0) {
    return 0.0;
  }

  // Cosinus
  const Scalar scalar = ::Dot(u, v);
  const Scalar cosinus = scalar / product;

  // Sinus
  const Vector3d w = ::Cross(u, v);
  const Scalar Nor_w = w.Length ();

  Scalar AbsSinus = Nor_w / product;

  // Remove degeneracy
  AbsSinus = (AbsSinus > 1) ? 1 : AbsSinus;
  AbsSinus = (AbsSinus < -1) ? -1 : AbsSinus;
  //if (AbsSinus > 1)
  //  TRACE ("Remove degeneracy (AbsSinus : %lg)\n", AbsSinus);

  if (cosinus >= 0)
    return asin (AbsSinus);
  else
    return (PI - asin (AbsSinus));
}

Vector3d Vector3d::Normalize(const Vector3d& v) {
  return v / v.Length();
}

Scalar Vector3d::DistanceSquare(const Vector3d& v1, const Vector3d& v2) {
  return (v1 - v2).LengthSquared();
}

Scalar Vector3d::Distance(const Vector3d & v1, const Vector3d & v2) {
  return (v1 - v2).Length();
}

Scalar Vector3d::Area(const Vector3d& pV0, const Vector3d& pV1,
                      const Vector3d& pV2) {
  const Vector3d bc(pV1, pV2);
  const Vector3d ba(pV1, pV0);
  const Vector3d v = ::Cross(bc, ba);
  return 0.5 * v.Length ();
}

std::ostream& operator<<(std::ostream& o, const Vector3d& v) {
  return o << "(" << v.x() << ", " << v.y() << ", " << v.z() << ")";
}

