// vim:ts=2 sw=2

/// \file   Vector3d.h
/// \brief  Interface for the Vector3d class.

#ifndef _VECTOR_3D_
#define _VECTOR_3D_

#include <iosfwd>
#include <limits>
#include <cassert>

#include "Scalar.h"

class Vector3d {
public :

  /// The zero vector
  static Vector3d Zero;

  /// Return the barycentric combination of the three vectors.
  static Vector3d BaryAverage(const Vector3d& b, const Vector3d v[3]);

  // Constructors
  Vector3d() { }

  Vector3d(const Scalar __x, const Scalar __y, const Scalar __z) {
    _vec[0] = __x;
    _vec[1] = __y;
    _vec[2] = __z;
  }

  Vector3d(const Scalar v[3]) {
    _vec[0] = v[0];
    _vec[1] = v[1];
    _vec[2] = v[2];
  }

  Vector3d(const Vector3d &vector) {
    Set(vector);
  }

  Vector3d(const Vector3d *pVector) {
    Set(pVector);
  }

  Vector3d(const Vector3d &a, const Vector3d& b) {
    Set(b - a);
  }

  Vector3d(const Vector3d *a, const Vector3d *b) {
    Set(*b - *a);
  }


  virtual ~Vector3d() { }

  void Clear() {
    _vec[0] = 0.f;
    _vec[1] = 0.f;
    _vec[2] = 0.f;
  }

  void Set(const Vector3d *pVector) {
    Set(pVector->GetArray());
  }

  void Set(const Vector3d& vector) {
    Set(vector.GetArray());
  }

  void Set(const Scalar __x, const Scalar __y, const Scalar __z) {
    _vec[0] = __x;
    _vec[1] = __y;
    _vec[2] = __z;
  }

  void Set(const Scalar v[3]) {
    _vec[0] = v[0];
    _vec[1] = v[1];
    _vec[2] = v[2];
  }

  void Set(const Vector3d& a, const Vector3d& b) {
    Set(b - a);
  }

  void Set(const Vector3d *a, const Vector3d *b) {
    Set(*b - *a);
  }

  Vector3d& operator=(const Vector3d& other) {
    _vec[0] = other[0];
    _vec[1] = other[1];
    _vec[2] = other[2];
    return *this;
  }

  // Data Access
  const Scalar* GetArray() const {
    return _vec;
  }

  void Get(Scalar& __x, Scalar& __y, Scalar& __z) const {
    __x = _vec[0];
    __y = _vec[1];
    __z = _vec[2];
  }

  void Get(Scalar v[]) const {
    v[0] = _vec[0];
    v[1] = _vec[1];
    v[2] = _vec[2];
  }

  // Per coordinate (explicit inline functions)
  void x(Scalar newX) {
    _vec[0] = newX;
  }

  void y(Scalar newY) {
    _vec[1] = newY;
  }

  void z(Scalar newZ) {
    _vec[2] = newZ;
  }

  // Data access (explicit inline functions)
  Scalar x() const {
    return _vec[0];
  }

  Scalar y() const {
    return _vec[1];
  }

  Scalar z() const {
    return _vec[2];
  }

  // Data access using indices
  Scalar& operator[](const int i) {
    assert(i >= 0 && i < 3);
    return _vec[i];
  }

  const Scalar& operator[](const int i) const {
    assert(i >= 0 && i < 3);
    return _vec[i];
  }

  // Operators
  Vector3d& operator+=(const Vector3d& rVector);
  Vector3d& operator+=(const Vector3d* pVector);
  Vector3d& operator-=(const Vector3d& rVector);
  Vector3d& operator-=(const Vector3d* pVector);
  Vector3d& operator*=(Scalar d);
  Vector3d& operator/=(Scalar d) {
    return * this *= (1.f / d);
  }

  // Nondestructive unary negation - returns a new vector
  Vector3d operator -() const;

  // Binary operators
  friend Vector3d operator+(const Vector3d& u, const Vector3d& v);
  friend Vector3d operator-(const Vector3d& u, const Vector3d& v);
  friend Vector3d operator*(const Scalar s, const Vector3d& u);
  friend Vector3d operator*(const Vector3d& u, const Scalar s) {
    return s * u;
  }

  friend Vector3d operator/(const Vector3d& u, Scalar s) {
    return (1.f / s) * u;
  }

  friend Vector3d Cross(const Vector3d& u, const Vector3d& v);
  friend Scalar Dot(const Vector3d& u, const Vector3d& v);
  friend int operator==(const Vector3d& v1, const Vector3d& v2);
  friend int operator!=(const Vector3d& v1, const Vector3d& v2) {
    return !(v1 == v2);
  }

  /// Return the angle between the two vectors.
  static Scalar Angle(const Vector3d& pU, const Vector3d& pV);

  bool Equals(const Vector3d& v, 
              const Scalar eps = 10.0f * std::numeric_limits<Scalar>::epsilon()
              ) const;

  inline Scalar Dot(const Vector3d& v) const;
  inline Scalar Dot(const Vector3d* pV) const;
  Vector3d Cross(const Vector3d& v) const;
  Vector3d Cross(const Vector3d* pV) const;

  // Misc
  Scalar Normalize();
  Scalar Normalize(Scalar value);
  Scalar Length() const;
  Scalar LengthSquared() const;
  int IsCollinear(Vector3d *pVector) const;
  int IsCollinear(Vector3d &vector) const;
  void Negate();
  Vector3d Rotate(Scalar angle, Vector3d Around);
  Vector3d Projection(const Vector3d* pV) const;

  /// Return the index of the largest component.
  int LargestComp() const;

  /// Multiply each component of this by the respective component of v.
  void CompMult(const Vector3d& v);

  /// Divide each component of this by the respective component of v.
  void CompDiv(const Vector3d& v);

  /// Multiply each component of v1 by the respective component of v2.
  static Vector3d CompMult(const Vector3d& v1, const Vector3d& v2);

  /// Divide each component of v1 by the respective component of v2.
  static Vector3d CompDiv(const Vector3d& v1, const Vector3d& v2);

  /// Return a normalised version of the vector.
  static Vector3d Normalize(const Vector3d& v);

  /// Return the squared distance between two vectors.
  static Scalar DistanceSquare(const Vector3d& v1, const Vector3d& v2);

  /// Return the distance between two vectors.
  static Scalar Distance(const Vector3d& v1, const Vector3d& v2);

  /// Return the area in the triangle defined by three points.
  static Scalar Area(const Vector3d& pV0, const Vector3d& pV1,
                     const Vector3d& pV2);

protected:
  Scalar _vec[3];  // Storage for the vector components
};

std::ostream& operator<<(std::ostream& o, const Vector3d& v);
Scalar Dot(const Vector3d& u, const Vector3d& v);


//********************************************
// Dot
//********************************************
Scalar Vector3d::Dot(const Vector3d& v) const {
  return (x() * v.x() +
          y() * v.y() +
          z() * v.z() );
}

//********************************************
// Dot
//********************************************
Scalar
Vector3d::Dot(const Vector3d* pV) const {
  return (x() * pV->x() +
          y() * pV->y() +
          z() * pV->z() );
}

inline
void Vector3d::CompMult(const Vector3d& v) {
  _vec[0] *= v.x();
  _vec[1] *= v.y();
  _vec[2] *= v.z();
}

inline
void Vector3d::CompDiv(const Vector3d& v) {
  _vec[0] /= v.x();
  _vec[1] /= v.y();
  _vec[2] /= v.z();
}

inline
Vector3d Vector3d::CompMult(const Vector3d& v1, const Vector3d& v2) {
  Scalar v[3];
  v[0] = v1.x() * v2.x();
  v[1] = v1.y() * v2.y();
  v[2] = v1.z() * v2.z();
  return Vector3d(v);
}

inline
Vector3d Vector3d::CompDiv(const Vector3d& v1, const Vector3d& v2) {
  Scalar v[3];
  v[0] = v1.x() / v2.x();
  v[1] = v1.y() / v2.y();
  v[2] = v1.z() / v2.z();
  return Vector3d(v);
}

inline
int Vector3d::LargestComp() const {
  if (_vec[0] >= _vec[1] && _vec[0] >= _vec[2]) {
    return 0;
  } else if (_vec[1] >= _vec[0] && _vec[1] >= _vec[2]) {
    return 1;
  } else {
    return 2;
  }
}

#endif // _VECTOR_3D_
