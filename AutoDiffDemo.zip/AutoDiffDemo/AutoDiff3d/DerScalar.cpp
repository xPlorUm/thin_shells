// CVS ID
// $Id: DerScalar.cpp,v 1.2 2003/09/18 20:11:52 eitan Exp $

// AUTHOR
// Eitan Grinspun

// CONTACT
// email:eitan[at]cs[dot]caltech[dot]edu, email:eitan[at]cat[dot]nyu[dot]edu

// DESCRIPTION
// This file declares the class DerScalar. This class represents scalar values
// that are dependent on other variables, ie, such values are represented
// a scalar/vector tuple carrying the value and derivative respectively.


#include <math.h>

#include "Matrix.h"
#include "Vector.h"
#include "Scalar.h"

#include "ConstScalar.h"
#include "DerScalar.h"
#include "DerVector.h"

DerScalar::DerScalar(void)
{
}

DerScalar::~DerScalar(void)
{
}


DerScalar::DerScalar( const Scalar& a, 
		      const Vector& __D ) 
  : m_a(a), m_D(__D) {
}


// computes the scalar negation and its derivative
DerScalar DerScalar::operator- ( void ) const {

  const Scalar& a  = v();
  const Vector& Da = D();

  return DerScalar( -a, -Da );
}


// computes the scalar-inverse and its derivative
// D(a^-1) = -(a^-2)(Da)
DerScalar DerScalar::Inv( void ) const {

  const Scalar& a  = v();
  const Vector& Da = D();

  return DerScalar( 1./a, 
		    -Da/(a*a) );
}


// computes the scalar-square-root and its derivative
// D(a^(1/2)) = 1/2(a^-(1/2))(Da)
DerScalar DerScalar::Sqrt( void ) const {

  const Scalar& a  = v();
  const Vector& Da = D();

  return DerScalar( sqrt(a),
		    (1./2. / sqrt(a)) * Da );
}


// computes the scalar-scalar sum and its derivative
DerScalar DerScalar::operator+ ( const DerScalar& Ts ) const {

  const Scalar& a  = v();
  const Vector& Da = D();

  const Scalar& b  = Ts.v();
  const Vector& Db = Ts.D();

  return DerScalar( a + b, Da + Db );
}


// computes the scalar-scalar difference and its derivative
DerScalar DerScalar::operator- ( const ConstScalar& s ) const {

  const Scalar& a  = v();
  const Vector& Da = D();

  const Scalar& b  = s.v();

  return DerScalar( a - b, Da );
}


// computes the scalar-scalar difference and its derivative
DerScalar DerScalar::operator- ( const DerScalar& Ts ) const {

  const Scalar& a  = v();
  const Vector& Da = D();

  const Scalar& b  = Ts.v();
  const Vector& Db = Ts.D();

  return DerScalar( a - b, Da - Db );
}


// computes the scalar-scalar product and its derivative
// uses chain rule: D(ab) = b(Da) where b is a constant, (Db)=0
DerScalar DerScalar::operator* ( const ConstScalar& s ) const {

  const Scalar& a  = v();
  const Vector& Da = D();

  const Scalar& b  = s.v();

  return DerScalar( a * b, b * Da );
}


// computes the scalar-scalar product and its derivative
// uses chain rule: D(ab) = b(Da) + a(Db)
DerScalar DerScalar::operator* ( const DerScalar& Ts ) const {

  const Scalar& a  = v();
  const Vector& Da = D();

  const Scalar& b  = Ts.v();
  const Vector& Db = Ts.D();

  return DerScalar( a * b, (b * Da) + (a * Db));
}


double myPow( double a, double b ) { return pow(a,b); }

// computes the scalar-scalar exponentiation and its derivative
// here the exponent is a constant
// D(a^b) = b * a^(b-1) * (Da)
DerScalar DerScalar::operator^ ( const ConstScalar& s ) const {

  const Scalar& a  = v();
  const Vector& Da = D();

  const Scalar& b  = s.v();

  return DerScalar( myPow(a,b), (b * myPow( a, b-1. )) * Da );
}


// computes scalar-vector product and its derivative
// uses chain rule: D(av) = v(Da) where v is constant, (Dv)=0
// where the first term is an open (matrix) product
DerVector DerScalar::operator* ( const Vector& v1 ) const {

  const Scalar& a  = v();
  const Vector& Da = D();

  const Vector& x  = v1;

  return DerVector( a * x, OuterProduct(x, Da) ); 
}


// computes scalar-vector product and its derivative
// uses chain rule: D(av) = v(Da) + a(Dv)
// where the first term is an open (matrix) product
DerVector DerScalar::operator* ( const DerVector& Tv ) const {

  const Scalar& a  = v();
  const Vector& Da = D();

  const Vector& x  = Tv.v();
  const Matrix& Dx = Tv.D();

  return DerVector( a * x,
		    OuterProduct(x, Da) + a * Dx );
}


// computes the scalar-valued arctangent of y/x and its derivative
// computes the scalar-valued arctangent of y/x and its derivative 
// (D atan2(b,a)) = b(Da)/(a^2 + b^2) when b is constant, (Db)=0
// D[ ArcTan[ a/b ] ] = -a / (a^2 + b^2) * Db, when Da = 0
DerScalar atan2( ConstScalar sa, DerScalar Tb ) {

  const Scalar& a  = sa.v();

  const Scalar& b  = Tb.v();
  const Vector& Db = Tb.D();

  return DerScalar( atan2(a,b),
		    (-a/(a*a + b*b)) * Db );
}


// computes the scalar-valued arctangent of y/x and its derivative 
// D[ ArcTan[ a/b ] ] = b / (a^2 + b^2) * Da, when Db = 0
DerScalar atan2( DerScalar Ta, ConstScalar sb ) {

  const Scalar& a  = Ta.v();
  const Vector& Da = Ta.D();

  const Scalar& b  = sb.v();

  return DerScalar( atan2(a,b),
		    (b/(a*a + b*b)) * Da );
}


// computes the scalar-valued arctangent of y/x and its derivative 
// (D atan2(y,x)) = (y(Dx) - x(Dy))/(x^2 + y^2)
DerScalar atan2( DerScalar Ta, DerScalar Tb ) {

  const Scalar& a  = Ta.v();
  const Vector& Da = Ta.D();

  const Scalar& b  = Tb.v();
  const Vector& Db = Tb.D();

  const Scalar den = a*a + b*b;

  return DerScalar( atan2(a,b),
		    (b/den) * Da - (a/den) * Db );
}


// can't afford to have sign zero, as it sometimes leads to unfortunate
// and unexpected zero derivatives
// returns a constant, not a tuple, does not compute derivative!!!
ConstScalar sign( DerScalar s ) {

  const Scalar& a  = s.v();

  if (a < 0) return ConstScalar( -1 );
  else return ConstScalar( +1 );
}
