// CVS ID
// $Id: DerScalar.h,v 1.1 2003/09/18 19:19:11 eitan Exp $

// AUTHOR
// Eitan Grinspun

// CONTACT
// email:eitan[at]cs[dot]caltech[dot]edu, email:eitan[at]cat[dot]nyu[dot]edu

// DESCRIPTION
// This file declares the class DerScalar. This class represents scalar values
// that are dependent on other variables, ie, such values are represented
// a scalar/vector tuple carrying the value and derivative respectively.

#ifndef __DERSCALAR_h
#define __DERSCALAR_h

#include "Scalar.h"

class ConstScalar;
class DerVector;

// DerScalar is a tuple of a scalar and the scalar's (vector-valued) derivative
class DerScalar
{
 public:
  DerScalar(void);
  ~DerScalar(void);

  DerScalar( const Scalar& a, 
	      const Vector& D );

  Scalar& v( void ) { return m_a; }

  const Scalar& v( void ) const { return m_a; }

  Vector& D( void ) { return m_D; }

  const Vector& D( void ) const { return m_D; }

  // computes the scalar negation and its derivative
  DerScalar operator- ( void ) const;

  // computes the scalar-inverse and its derivative
  DerScalar Inv( void ) const;

  // computes the scalar-square-root and its derivative
  DerScalar Sqrt( void ) const;

  // computes the scalar-scalar sum and its derivative
  DerScalar operator+ ( const DerScalar& Ts ) const;

  // computes the scalar-scalar difference and its derivative
  DerScalar operator- ( const ConstScalar& s ) const;

  // computes the scalar-scalar difference and its derivative
  DerScalar operator- ( const DerScalar& Ts ) const;

  // computes the scalar-scalar product and its derivative
  DerScalar operator* ( const ConstScalar& s ) const;

  // computes the scalar-scalar product and its derivative
  DerScalar operator* ( const DerScalar& Ts ) const;

  // computes the scalar-scalar exponentiation and its derivative
  // here the exponent is a constant
  DerScalar operator^ ( const ConstScalar& s ) const;

  // computes scalar-vector product and its derivative
  // uses chain rule: D(av) = v(Da) where v is constant, (Dv)=0
  // where the first term is an open (matrix) product
  DerVector operator* ( const Vector& v ) const;

  // computes scalar-vector product and its derivative
  // uses chain rule: D(av) = v(Da) + a(Dv)
  // where the first term is an open (matrix) product
  DerVector operator* ( const DerVector& Tv ) const;

 private:

  Scalar m_a;
  Vector m_D;
};


DerScalar atan2( ConstScalar s1, DerScalar s2 );

DerScalar atan2( DerScalar s1, ConstScalar s2 );

DerScalar atan2( DerScalar s1, DerScalar s2 );

ConstScalar sign( DerScalar s );


#endif //  #ifdef __DERSCALAR_h
