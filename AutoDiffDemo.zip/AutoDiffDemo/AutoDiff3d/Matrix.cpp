// CVS ID
// $Id: Matrix.cpp,v 1.2 2003/09/22 23:11:13 eitan Exp $

// AUTHOR
// Eitan Grinspun

// CONTACT
// email:eitan[at]cs[dot]caltech[dot]edu, email:eitan[at]cat[dot]nyu[dot]edu

// DESCRIPTION
// This file implements the class Matrix. This class represents
// an NxN matrix, where N is given by the define MATRIX_N

#include <iostream>

using namespace ::std;

#include "Matrix.h"

const Matrix Matrix::Zero(0.);

const Matrix Matrix::Identity(1.);

// construct matrix with values on diagonal
Matrix::Matrix( Scalar diagonalValue ) {

  Matrix& A = *this;

  int i, j;
  for ( i = 0; i < MATRIX_N; ++i )
    for ( j = 0; j < MATRIX_N; ++j ) {
      
      A[i][j] = 0;
    }

  for ( i = 0; i < MATRIX_N; ++i ) {

    A[i][i] = diagonalValue;
  }
}


// unary negation operator
Matrix Matrix::operator- ( void ) const {

  const Matrix& A = *this;
  Matrix C;

  int i, j;
  for ( i = 0; i < MATRIX_N; ++i )
    for ( j = 0; j < MATRIX_N; ++j ) {

      C[i][j] = -A[i][j];
    }

  return C;  
}


// addition
Matrix Matrix::operator+ ( const Matrix& B ) const {

  const Matrix &A = *this;
  Matrix C;

  int i, j;
  for ( i = 0; i < MATRIX_N; ++i )
    for ( j = 0; j < MATRIX_N; ++j ) {

      C[i][j] = A[i][j] + B[i][j];
    }

  return C;
}


// subtraction
Matrix Matrix::operator- ( const Matrix& B ) const {

  const Matrix &A = *this;
  Matrix C;

  int i, j;
  for ( i = 0; i < MATRIX_N; ++i )
    for ( j = 0; j < MATRIX_N; ++j ) {

      C[i][j] = A[i][j] - B[i][j];
    }

  return C;
}


// multiplication
// computed as (AB)_ij := A_ik B_kj
Matrix Matrix::operator* ( const Matrix& B ) const {

  const Matrix& A = *this;
  Matrix result;
  for (int i = 0; i < MATRIX_N; ++i)
    for (int j = 0; j < MATRIX_N; ++j) {
      result[i][j] = 0;
      for (int k = 0; k < MATRIX_N; ++k) {
	result[i][j] += A[i][k] * B[k][j];
      }
    }
  return result;
}


// returns the (matrix-valued) product of a scalar and a matrix
Matrix operator* ( const float& a, const Matrix& B ) {

  Matrix C;

  int i, j;
  for ( i = 0; i < MATRIX_N; ++i )
    for ( j = 0; j < MATRIX_N; ++j ) {

      C[i][j] = a * B[i][j];
    }

  return C;
}


// returns the (vector-valued) product of a vector and a matrix
Vector operator* ( const Vector& x, const Matrix& B ) {

  Vector y;

  int i, j;
  for ( j = 0; j < MATRIX_N; ++j ) {

    y[j] = 0.;
    for ( i = 0; i < MATRIX_N; ++i ) {

      y[j] += x[i] * B[i][j];
    }  
  }

  return y;
}


// the open product of two vectors is a matrix
// (also known as the matrix product)
Matrix OuterProduct( const Vector& x, const Vector& y ) {

  Matrix A;

  for (int i = 0; i < MATRIX_N; ++i)
    for (int j = 0; j < MATRIX_N; ++j) {

      A[i][j] = x[i] * y[j];
    }

  return A;
}


// fill the NxN matrix of doubles with the current matrix values
void Matrix::FillRowMajor( double Aval[N*N] ) {

  Matrix& A = *this;
  int k = 0;
  for (int i = 0; i < N; ++i) {
    for (int j = 0; j < N; ++j) {

      Aval[k++] = A[i][j];
    }
  }
}


ostream& operator<< ( ostream& os, const Matrix& A ) {

  for (int i = 0; i < MATRIX_N; ++i) {
    for (int j = 0; j < MATRIX_N; ++j) {

      os << A[i][j] << "\t";
    }

    os << endl;
  }

  return os;
}
