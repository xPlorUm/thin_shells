// CVS ID
// $Id: test.cpp,v 1.1 2003/09/18 22:17:17 eitan Exp $

// AUTHOR
// Eitan Grinspun

// CONTACT
// email:eitan[at]cs[dot]caltech[dot]edu, email:eitan[at]cat[dot]nyu[dot]edu

// DESCRIPTION
// This file implements a test stub for the automatic differentiation code.

#include <iostream>
#include <math.h>

using namespace ::std;

#include "Matrix.h"
#include "Vector.h"
#include "Scalar.h"

#include "ConstScalar.h"
#include "DerScalar.h"
#include "DerVector.h"

void print( char* name, char* formula, const DerScalar& Ta ) {

	cout << name << " = " << formula << " = " << Ta.v() << endl;
	cout << "(D" << name << ") = ";
	cout << Ta.D();
	cout << endl << endl;;
}

void print( char* name, char* formula, const DerVector& Tx ) {

	cout << name << " = " << formula << " = ";
	cout << Tx.v();
	cout << endl;
	cout << "(D" << name << ") = " << endl;
	cout << Tx.D();
	cout << endl << endl;
}


void Compute( char *x, DerVector& Tx, DerVector& Ty ) {

	cout << "Computing derivatives w.r.t. " << x << endl;
	cout << "----------------------------------" << endl << endl;

	DerVector Tz;
	DerScalar Ta, Tb, Tc;

	Tx.v() = Vector(1,2,0);  // x dot x = 5
	Ty.v() = Vector(2,3,0); // x dot y = 13

	print( "x", "x", Tx );
	print( "y", "y", Ty );

	Ta = Tx.Dot( Ty );
	print( "a", "x dot y", Ta );

	Tb = Tx.Dot( Tx );
	print( "b", "x dot x", Tb );

	Tc = Ta + Tb;
	print( "c", "a + b", Tc );

	Tc = Ta - Tb;
	print( "c", "a - b", Tc );

	Tc = Ta * Tb;
	print( "c", "a * b", Tc );

	Tc = Tx.Length();
	print( "c", "||x||", Tc );

	Tz = Ta * Tx;
	print( "z", "a * x", Tz );

	ConstScalar two(2);
	Tz = Tx + two * Ty;
	print( "z", "x + 2y", Tz );
}



int main(void)
{
  // This example shows how AutoDiff3d is used to differentiate
  // scalar- and vector-valued expressions with respect to
  // vector-valued independent variables.

  // A DerVector is a (potentially) dependent variable. It carries
  // both a vector value and a matrix-valued derivative.  It is always
  // safe to declare a vector as a DerVector, but it is needlessly
  // inefficient if the vector is known to be independent.  Since we
  // will be differentiating with respect to the vector Tp, the
  // argument Matrix::Identity sets the derivative of Tp to the
  // Identity. The first argument is the value of the vector, (0 0 1).
  DerVector Tp( Vector(0,0,2), Matrix::Identity );

  // A Vector is a variable known to be independent. The code is
  // optimised to specially handle independent quantities. Note that
  // dependent variables are value-derivative tuples hence their name
  // is prefixed with a capital T, while independent variables are
  // treated as constants during differentiation hence their name
  // starts with a C. The argument is the value of the vector, (1 2 3).
  Vector Cq(1,2,3);

  cout << "Let p = " << Tp.v() << endl;
  cout << "Let q = " << Cq << endl;

  DerScalar Ta = Tp.Dot(Cq); // let a = dot product of p and q

  // For any tuple Ta, Ta.v() returns the value, and Ta.D() returns
  // the derivative.
  cout << "Then a = p.dot.q = " << Ta.v() << endl;

  cout << "...and the derivative of a w.r.t. p is " << Ta.D() << endl;

  DerScalar Tb = Tp.Dot(Tp); // let b = dot product of p with itself

  cout << "Then b = p.dot.p = " << Tb.v() << endl;

  cout << "...and the derivative of b w.r.t. p is " << Tb.D() << endl;

  // Now a different computation:

  cout << "Here we go again...";

  Tp.v() = Vector(3,1,4);
  Cq     = Vector(1,2,4);

  cout << "Let p = " << Tp.v() << endl;
  cout << "Let q = " << Cq << endl;

  Ta = (Tp.Dot(Cq) * Tp.Cross(Cq)).Length();

  // For any tuple Ta, Ta.v() returns the value, and Ta.D() returns
  // the derivative.
  cout << "Then a = |(p.dot.q) (p.cross.q)| = " << Ta.v() << endl;

  cout << "...and the derivative of a w.r.t. p is " << Ta.D() << endl;

  Tb = (Tp.Dot(Tp)).Sqrt().Inv(); // let b be the inverse of the length of p

  cout << "Then b = (p.dot.p)^(-1/2) = " << Tb.v() << endl;

  cout << "...and the derivative of b w.r.t. p is " << Tb.D() << endl;

  // This second test shows how the same piece of code
  // (the function Compute) can be called twice to differentiate 
  // w.r.t. two different variables.

  DerVector Tx, Ty;

  Tx.D() = Matrix::Identity;
  Ty.D() = Matrix::Zero;
  
  Compute( "x", Tx, Ty );
  
  Ty.D() = Matrix::Identity;
  Tx.D() = Matrix::Zero;
  
  Compute( "y", Tx, Ty );
}
