// CVS ID
// $Id: Vector.h,v 1.2 2003/09/23 23:37:05 eitan Exp $

// AUTHOR
// Eitan Grinspun

// CONTACT
// email:eitan[at]cs[dot]caltech[dot]edu, email:eitan[at]cat[dot]nyu[dot]edu

// DESCRIPTION
// This file declares the type Vector. This type represents spatial vectors.

#ifndef __MYVECTOR_H
#define __MYVECTOR_H

#include "Vector3d.h"

typedef Vector3d Vector;

#endif //#define __SCALAR_H
