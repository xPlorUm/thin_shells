// CVS ID
// $Id: DerVector.cpp,v 1.4 2003/09/18 22:17:16 eitan Exp $

// AUTHOR
// Eitan Grinspun

// CONTACT
// email:eitan[at]cs[dot]caltech[dot]edu, email:eitan[at]cat[dot]nyu[dot]edu

// DESCRIPTION
// This file implements the class DerVector. This class represents vectors
// that are dependent on other variables, ie, such vectors are represented
// a vector/matrix tuple carrying the value and derivative respectively.

#include <math.h>

#include "Matrix.h"
#include "Vector.h"
#include "Scalar.h"

#include "ConstScalar.h"
#include "ConstVector.h"
#include "DerScalar.h"
#include "DerVector.h"

DerVector::DerVector(void) {
}

DerVector::~DerVector(void) {
}


DerVector::DerVector( const Vector& v, const Matrix& D ) 
  : m_v( v ), m_D( D ) {}


DerVector::DerVector( const ConstVector& v, 
		      const Matrix& D )
  : m_v( v.v() ), m_D( D ) {}


// computes the vector norm and its derivative
// uses the chain rule: D(norm(x)) = (D norm)(x) (Dx)
DerScalar DerVector::Length( void ) const {

  const Vector& x  = v();
  const Matrix& Dx = D();

  return DerScalar( x.Length(),
		    DiffLength(x) * Dx );
}


// computes the vector negation and its derivative
DerVector DerVector::operator- ( void ) const {

  const Vector& x  = v();
  const Matrix& Dx = D();

  return DerVector( -x, -Dx);
}


// computes the vector-vector sum and its derivative
DerVector DerVector::operator+ ( const ConstVector& v2 ) const {

  const Vector& x  = v();
  const Matrix& Dx = D();

  const Vector& y = v2.v();
  
  return DerVector( x + y, Dx );
}


// computes the vector-vector sum and its derivative
DerVector DerVector::operator+ ( const DerVector& Tv2 ) const {

  const Vector& x = v();
  const Matrix& Dx = D();

  const Vector& y = Tv2.v();
  const Matrix& Dy = Tv2.D();

  return DerVector( (x + y), (Dx + Dy) );
}


// computes the vector-vector difference and its derivative
DerVector DerVector::operator- ( const ConstVector& v2 ) const {

  const Vector& x  = v();
  const Matrix& Dx = D();

  const Vector& y = v2.v();
  
  return DerVector( x - y, Dx );
}


// computes the vector-vector difference and its derivative
DerVector DerVector::operator- ( const DerVector& Tv2 ) const {

  const Vector& x  = v();
  const Matrix& Dx = D();

  const Vector& y  = Tv2.v();
  const Matrix& Dy = Tv2.D();

  return DerVector( (x - y), (Dx - Dy) );
}


// computes dot product and its derivative
// uses chain rule: D(a.b) = b(Da)  where b is a constant, (Db)=0
DerScalar DerVector::Dot( const ConstVector& v2 ) const {

  const Vector& x = v();
  const Matrix& Dx = D();

  const Vector& y = v2.v();

  return DerScalar( x. Dot( y ),
	            y*Dx );
}


// computes dot product and its derivative
// uses chain rule: D(a.b) = a(Db) + b(Da)
DerScalar DerVector::Dot( const DerVector& Tv2 ) const {

  const Vector& x = v();
  const Matrix& Dx = D();

  const Vector& y = Tv2.v();
  const Matrix& Dy = Tv2.D();

  return DerScalar( x. Dot( y ),
		    x*Dy + y*Dx );
}


Vector DerVector::DiffLength( const Vector& x ) const {

  Scalar n2 = x. Dot( x );

  if (n2 == 0) return x; // d/dx ||0-vector|| = 0-vector

  else return pow((double)n2, -0.5) * x;
}


#if 0
// computes cross product and its derivative
// uses chain rule: D(a x b) = Dx(a x b)(Da) + Dy(a x b)(Db)
DerVector DerVector::Cross( const DerVector& Tv2 ) const {

  const Vector& x = v();
  const Matrix& Dx = D();

  const Vector& y = Tv2.v();
  const Matrix& Dy = Tv2.D();

  return DerVector( x. Cross( y ),
		    DiffCross1(x,y) * Dx + DiffCross2(x,y) * Dy );
}

// computes cross product and its derivative
// uses chain rule: D(a x b) = Dx(a x b)(Da), b is constant, (Db)=0
DerVector DerVector::Cross( const ConstVector& v2 ) const {

  const Vector& x = v();
  const Matrix& Dx = D();

  const Vector& y = v2.v();

  return DerVector( x. Cross( y ),
		    DiffCross1(x,y) * Dx );
}
#endif
