///////////////////////////////////////////////////////////////////////////
//                                                                       //
//  Class: Vector2d                                                      //
//                                                                       //
//  2D Vector to represent points or directions.  Each component of the  //
//  vector is stored as a float.                                         //
//                                                                       //
///////////////////////////////////////////////////////////////////////////

#ifndef _VECTOR_2D_
#define _VECTOR_2D_

#include <assert.h>
#include <iostream>

using namespace ::std;

class Vector2d
{

private :

protected:

 float vec[2];  // Storage for the vector components

public :

  static Vector2d Zero;

  // Constructors
  Vector2d() { vec[0] = vec[1] = 0; }
  Vector2d(const float x, const float y)
    { vec[0] = x; vec[1] = y; }
  Vector2d(const float v[2])
    { vec[0] = v[0]; vec[1] = v[1]; }
  Vector2d(const Vector2d &vector)  { Set(vector); }
  Vector2d(const Vector2d *pVector) { Set(pVector); }
  Vector2d(const double v[2])
    { vec[0] = v[0]; vec[1] = v[1]; }

  virtual ~Vector2d() { }

  // Data setting
  void Clear()
    { vec[0] = 0.f; vec[1] = 0.f; }
  void Set(const Vector2d *pVector) { Set(pVector->GetArray()); }
  void Set(const Vector2d& vector)  { Set(vector.GetArray()); }
  void Set(const float x, const float y)
    { vec[0] = x; vec[1] = y; }
  void Set(const float v[2])
    { vec[0] = v[0]; vec[1] = v[1]; }

  // Data Access
  const float* GetArray() const { return vec; }
  void         Get(float& x, float& y) const;
  void         Get(float* array) const;
  void         Get(double* array) const;

  // Per coordinate (explicit inline functions)
  void x(float newX) { vec[0] = newX; }
  void y(float newY) { vec[1] = newY; }

  // Data access (explicit inline functions)
  float x() const { return (vec[0]); }
  float y() const { return (vec[1]); }

  // Data access using indices
  float&       operator[] (int i)       { return (vec[i]); }
  const float& operator[] (int i) const { return (vec[i]); }

  // Operators
  inline Vector2d& operator+=(const Vector2d& rVector);
  inline Vector2d& operator+=(const Vector2d* pVector);
  inline Vector2d& operator-=(const Vector2d& rVector);
  inline Vector2d& operator-=(const Vector2d* pVector);
  inline Vector2d& operator*=(float d);
  inline Vector2d& operator/=(float d) { return *this *= (1.f/d); }

  // Nondestructive unary negation - returns a new vector
  Vector2d  operator -() const;

  // Binary operators
  friend Vector2d operator+(const Vector2d& u, const Vector2d& v);
  friend Vector2d operator-(const Vector2d& u, const Vector2d& v);
  friend Vector2d operator*(float s,            const Vector2d& u);
  friend Vector2d operator*(const Vector2d& u, float s)
    { return s * u; }
  friend Vector2d operator/(const Vector2d& u, float s)
      { return (1.f/s) * u; }
  friend int operator==(const Vector2d& v1, const Vector2d& v2);
  friend int operator!=(const Vector2d& v1, const Vector2d& v2)
    { return !(v1 == v2); }

  int Equals(const Vector2d& v, float tolerence) const;

  inline float Dot(const Vector2d& v) const;
  inline float Dot(const Vector2d* pV) const;

  // Misc
  float Normalize();
  float Normalize(float value);
  float Length() const;
  float LengthSquared() const;
  int IsCollinear(Vector2d *pVector) const;
  int IsCollinear(Vector2d &vector) const;
  inline void Negate();
  inline void J();

  // returns a unit vector with the same direction
  Vector2d Unit( void ) const {

    assert( Length() > 0. );

    Vector2d result = (*this) / Length();
    return result;
  }


  // returns a vector rotated 90 degrees clockwise
  Vector2d PerpCW( void ) const {

    return Vector2d( vec[1], -vec[0] );
  }
};

//********************************************
// Dot
//********************************************
float
Vector2d::Dot(const Vector2d& v) const
{
  return (x() * v.x() +
	  y() * v.y());
}

//********************************************
// Dot
//********************************************
float
Vector2d::Dot(const Vector2d* pV) const
{
  return (x() * pV->x() +
	  y() * pV->y());
}


//********************************************
// Operator +=
//********************************************
Vector2d&
Vector2d::operator+=(const Vector2d& rVector)
{
  vec[0] += rVector.x();
  vec[1] += rVector.y();
  return *this;
}

//********************************************
// Operator -=
//********************************************
Vector2d&
Vector2d::operator-=(const Vector2d& rVector)
{
  vec[0] -= rVector.x();
  vec[1] -= rVector.y();
  return *this;
}

//********************************************
// Operator *=
//********************************************
Vector2d&
Vector2d::operator*=(float d)
{
  vec[0] *= d;
  vec[1] *= d;
  return *this;
}


inline ostream& operator<< ( ostream& os, const Vector2d& v ) {
  
  os << "( " << v[0] << ", " << v[1] << ") ";

  return os;
}


#endif // _VECTOR_2D_


