// CVS ID
// $Id: Scalar.h,v 1.1 2003/09/23 18:30:43 eitan Exp $

// AUTHOR
// Eitan Grinspun

// CONTACT
// email:eitan[at]cs[dot]caltech[dot]edu, email:eitan[at]cat[dot]nyu[dot]edu

// DESCRIPTION
// This file declares the type Scalar. This type represents 
// scalar (floating-point) values.

#ifndef __SCALAR_H
#define __SCALAR_H

typedef float Scalar;

#endif //#define __SCALAR_H
