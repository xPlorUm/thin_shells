// CVS ID
// $Id: DerVector.h,v 1.3 2003/09/18 20:11:52 eitan Exp $

// AUTHOR
// Eitan Grinspun

// CONTACT
// email:eitan[at]cs[dot]caltech[dot]edu, email:eitan[at]cat[dot]nyu[dot]edu

// DESCRIPTION
// This file declares the class DerVector. This class represents vectors
// that are dependent on other variables, ie, such vectors are represented
// a vector/matrix tuple carrying the value and derivative respectively.

#ifndef __DERVECTOR_H
#define __DERVECTOR_H

#include "Matrix.h"
#include "Vector.h"
#include "Scalar.h"

class ConstScalar;
class ConstVector;
class DerScalar;

// DerVector is a tuple of a vector and the vector's derivative (a matrix)
class DerVector
{
 public:
  DerVector(void);
  ~DerVector(void);

  DerVector( const Vector& v, const Matrix& Dv );

  DerVector( const ConstVector& v, const Matrix& Dv );

  Vector& v( void ) { return m_v; }

  const Vector& v( void ) const { return m_v; }

  Matrix& D( void ) { return m_D; }

  const Matrix& D( void ) const { return m_D; }

  DerScalar Length( void ) const;

  // computes the vector negation and its derivative
  DerVector operator- ( void ) const;

  // computes the vector-vector sum and its derivative
  DerVector operator+ ( const ConstVector& v2 ) const;

  // computes the vector-vector sum and its derivative
  DerVector operator+ ( const DerVector& Tv2 ) const;

  // computes the vector-vector difference and its derivative
  DerVector operator- ( const ConstVector& v2 ) const;

  // computes the vector-vector difference and its derivative
  DerVector operator- ( const DerVector& Tv2 ) const;

  // computes the vector-vector (scalar-valued) dot product
  // and its derivative
  DerScalar Dot( const ConstVector& v2 ) const;

  // computes the vector-vector (scalar-valued) dot product
  // and its derivative
  DerScalar Dot( const DerVector& Tv2 ) const;

#if 0
  // computes the vector-vector (vector-valued) cross product
  // and its derivative
  DerVector Cross( const DerVector& Tv2 ) const;

  // computes the vector-vector (vector-valued) cross product
  // and its derivative
  DerVector Cross( const ConstVector& v2 ) const;
#endif

  // Helper methods
 private:
  Vector DiffLength( const Vector& x ) const;

 private:
  Vector m_v;
  Matrix m_D;
};


#endif // #define __DERVECTOR_H
