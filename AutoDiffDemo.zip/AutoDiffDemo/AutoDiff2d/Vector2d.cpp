//********************************************
// Vector2d.cpp
//********************************************
// class Vector2d
//********************************************
// mmeyer@gg.caltech.edu
// Created :  09/07/00
// Modified : 09/07/00
//********************************************

#include <math.h>
#include <stdio.h>

#include "Vector2d.h"


Vector2d Vector2d::Zero(0,0);

//////////////////////////////////////////////
// CONSTRUCTORS
//////////////////////////////////////////////


//////////////////////////////////////////////
// DATA
//////////////////////////////////////////////


//********************************************
// Get
//  Get the 2 components of the vector
//********************************************
void
Vector2d::Get(float& x, float& y) const
{
  x = vec[0];
  y = vec[1];
}


void Vector2d::Get(float* array) const {

  array[0] = vec[0];
  array[1] = vec[1];
}


void Vector2d::Get(double* array) const {

  array[0] = vec[0];
  array[1] = vec[1];
}



//////////////////////////////////////////////
//////////////////////////////////////////////
// PROCESSING
//////////////////////////////////////////////
//////////////////////////////////////////////


//********************************************
// Normalize
//********************************************
float
Vector2d::Normalize()
{
  float len = Length();
  if(len != 0.0f)
    (*this) *= (1.0/len);
  else
    Set(0.f,0.f);

  return len;
}

//********************************************
// Normalize
//********************************************
float
Vector2d::Normalize(float value)
{
  float len = Length();
  if(len != 0.0f)
    (*this) *= (value/len);
  else
    Set(0.f,0.f);

  return len;
}

//********************************************
// LengthSquared
//********************************************
float
Vector2d::LengthSquared() const
{
  return ( (float)vec[0]*(float)vec[0]
	 + (float)vec[1]*(float)vec[1]);
}
	
//********************************************
// Length
//********************************************
float
Vector2d::Length() const
{
  return sqrt( (float)vec[0]*(float)vec[0]
	     + (float)vec[1]*(float)vec[1]);
}
	
//********************************************
// IsCollinear
//********************************************
int
Vector2d::IsCollinear(Vector2d *pVector) const
{
  float x = pVector->x() / vec[0];
  float y = pVector->y() / vec[1];
  return (x == y);
}

//********************************************
// IsCollinear
//********************************************
int
Vector2d::IsCollinear(Vector2d &vector) const
{
  float x = vector.x() / vec[0];
  float y = vector.y() / vec[1];
  return (x == y);
}

//********************************************
// Rotate 90 degrees
//********************************************
void
Vector2d::J()
{
  vec[0] = -vec[1];
  vec[1] = vec[0];
}

//********************************************
// Negate
//********************************************
void
Vector2d::Negate()
{
  vec[0] = -vec[0];
  vec[1] = -vec[1];
}

//////////////////////////////////////////////
// OPERATORS
//////////////////////////////////////////////



//********************************************
// Operator +=
//********************************************
Vector2d&
Vector2d::operator+=(const Vector2d* pVector)
{
  vec[0] += pVector->x();
  vec[1] += pVector->y();
  return *this;
}


//********************************************
// Operator -=
//********************************************
Vector2d&
Vector2d::operator-=(const Vector2d* pVector)
{
  vec[0] -= pVector->x();
  vec[1] -= pVector->y();
  return *this;
}


//********************************************
// Operator -
//  Nondestructive unary -
//  Returns a new vector.
//********************************************
Vector2d
Vector2d::operator -() const
{
  return Vector2d(-vec[0],-vec[1]);
}


//********************************************
// Operator ==
//********************************************
int
operator==(const Vector2d& v1, const Vector2d& v2)
{
  return (v1.vec[0] == v2.vec[0] &&
	  v1.vec[1] == v2.vec[1]);
}

//********************************************
// Equals
//  Determines if two vectors are equal
//  within a tolerence (squared distance).
//********************************************
int
Vector2d::Equals(const Vector2d& v, float tolerence) const
{
  Vector2d diff = *this - v;

  return diff.LengthSquared() <= tolerence;
}


//********************************************
// Operator + 
//********************************************
Vector2d
operator+(const Vector2d& u, const Vector2d& v)
{
  return Vector2d(u.vec[0]+v.vec[0],u.vec[1]+v.vec[1]);
}

//********************************************
// Operator -
//********************************************
Vector2d
operator-(const Vector2d& u, const Vector2d& v)
{
  return Vector2d(u.vec[0]-v.vec[0],u.vec[1]-v.vec[1]);
}

//********************************************
// Operator * 
//********************************************
Vector2d
operator*(float s, const Vector2d& u)
{
  return Vector2d(u.vec[0] * s, u.vec[1] * s);
}


// ** EOF **
