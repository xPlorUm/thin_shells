// CVS ID
// $Id: ConstVector.h,v 1.3 2003/09/18 20:11:52 eitan Exp $

// AUTHOR
// Eitan Grinspun

// CONTACT
// email:eitan[at]cs[dot]caltech[dot]edu, email:eitan[at]cat[dot]nyu[dot]edu

// DESCRIPTION
// This file declares the class ConstVector. This class represents vectors
// that are independent variables, ie, such vectors need not carry
// derivative information, as their derivative w.r.t. any other independent
// variable is 0.

#ifndef __CONSTVECTOR_H
#define __CONSTVECTOR_H

#include "Vector.h"
#include "Scalar.h"

class ConstScalar;
class DerScalar;
class DerVector;

class ConstVector
{
 public:
  ConstVector(void);
  ~ConstVector(void);

  ConstVector( const Vector& v );

  static const ConstVector Zero;

  void Clear( void ) { m_v = Vector::Zero; }

  Vector& v( void ) { return m_v; }

  const Vector& v( void ) const { return m_v; }

  // computes the length of the vector
  ConstScalar Length( void ) const;

  // computes the vector negation
  ConstVector operator- ( void ) const;

  // computes the vector-vector sum
  ConstVector operator+ ( const ConstVector& v2 ) const;

  // computes the vector-vector sum and its derivative
  DerVector operator+ ( const DerVector& Tv2 ) const;

  // computes the vector-vector difference
  ConstVector operator- ( const ConstVector& v2 ) const;

  // computes the vector-vector difference and its derivative
  DerVector operator- ( const DerVector& Tv2 ) const;

  // computes the vector-vector (scalar-valued) dot product
  ConstScalar Dot( const ConstVector& v2 ) const;

  // computes the vector-vector (scalar-valued) dot product
  // and its derivative
  DerScalar Dot( const DerVector& Tv2 ) const;

  // computes division by constant scalar
  ConstVector operator /( const ConstScalar& a );

  // alternative notation for addition
  void operator +=( const ConstVector& v2 );

#if 0
  // computes the vector-vector (vector-valued) cross product
  ConstVector Cross( const ConstVector& v2 ) const;

  // computes the vector-vector (vector-valued) cross product
  // and its derivative
  DerVector Cross( const DerVector& Tv2 ) const;
#endif

 private:
  Vector m_v;
};


#endif  // #ifndef __CONSTVECTOR_H
