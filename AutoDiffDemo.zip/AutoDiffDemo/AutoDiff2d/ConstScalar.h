// CVS ID
// $Id: ConstScalar.h,v 1.1 2003/09/18 19:19:11 eitan Exp $

// AUTHOR
// Eitan Grinspun

// CONTACT
// email:eitan[at]cs[dot]caltech[dot]edu, email:eitan[at]cat[dot]nyu[dot]edu

// DESCRIPTION
// This file declares the class ConstScalar. This class represents scalar values
// that are independent variables, ie, such values need not carry
// derivative information, as their derivative w.r.t. any other independent
// variable is 0.

#ifndef __CONSTSCALAR_H
#define __CONSTSCALAR_H

#include "Scalar.h"

class DerScalar;
class ConstVector;
class DerVector;

// ConstScalar is a constant scalar value (does not track derivatives)
class ConstScalar
{
 public:

  // constructor (does not clear the value!)
  ConstScalar(void);

  // destructor
  ~ConstScalar(void);

  ConstScalar( const Scalar& a ) : m_a(a) {}

  Scalar& v( void ) { return m_a; }

  const Scalar& v( void ) const { return m_a; }

  ConstScalar& operator= ( double a ) { 
    m_a = a;
    return *this;
  }

  bool operator< ( ConstScalar b ) const { return m_a < b.m_a; }

  // computes the scalar negation
  ConstScalar operator- ( void ) const;

  // computes the scalar-inverse
  ConstScalar Inv( void ) const;

  // computes the scalar-square-root
  ConstScalar Sqrt( void ) const;

  // computes the scalar-scalar sum
  ConstScalar operator+ ( const ConstScalar& s ) const;

  // computes the scalar-scalar sum and its derivative
  DerScalar operator+ ( const DerScalar& Ts ) const;

  // computes the scalar-scalar difference
  ConstScalar operator- ( const ConstScalar& s ) const;

  // computes the scalar-scalar difference and its derivative
  DerScalar operator- ( const DerScalar& Ts ) const;

  // computes the scalar-scalar product
  ConstScalar operator* ( const ConstScalar& s ) const;

  // computes the scalar-scalar product and its derivative
  DerScalar operator* ( const DerScalar& Ts ) const;

  // computes the scalar-scalar quotient
  ConstScalar operator/ ( const ConstScalar& s ) const;

  // computes scalar-vector product
  ConstVector operator* ( const ConstVector& Tv ) const;

  // computes scalar-vector product and its derivative
  // since a is a constant, D(av) = a(Dv) 
  DerVector operator* ( const DerVector& Tv ) const;

 private:

  Scalar m_a;
};


ConstScalar atan2( ConstScalar a, ConstScalar b );

ConstScalar sign( ConstScalar a );

inline ConstScalar operator+ ( double a, ConstScalar b ) {
  return ConstScalar(a) + b;
}

inline ConstScalar operator+ ( ConstScalar s, double b ) {
  return s + ConstScalar(b);
}

inline ConstScalar operator- ( double a, ConstScalar s ) {
  return ConstScalar(a) - s;
}

inline ConstScalar operator- ( ConstScalar s, double b ) {
  return s - ConstScalar(b);
}

inline ConstScalar operator* ( double a, ConstScalar s ) {
  return ConstScalar(a) * s;
}

inline ConstScalar operator* ( ConstScalar s, double b ) {
  return s * ConstScalar(b);
}


#endif // #define __CONSTSCALAR_H
