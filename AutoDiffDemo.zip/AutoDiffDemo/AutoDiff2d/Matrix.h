// CVS ID
// $Id: Matrix.h,v 1.3 2003/09/22 23:11:13 eitan Exp $

// AUTHOR
// Eitan Grinspun

// CONTACT
// email:eitan[at]cs[dot]caltech[dot]edu, email:eitan[at]cat[dot]nyu[dot]edu

// DESCRIPTION
// This file declares the class Matrix. This class represents
// an NxN matrix, where N is given by the define MATRIX_N

#ifndef __MATRIX_H
#define __MATRIX_H

#define MATRIX_N (2)

#include "Scalar.h"
#include "Vector.h"

// let the world know that Matrix uses row-major storage
#define MATRIX_ROWMAJOR

class Matrix {

 public:

  static const int N = MATRIX_N;

  typedef Scalar Row[N];

  typedef Row DataMatrix[N];

  static const Matrix Zero;

  static const Matrix Identity;

  Matrix( void ) {}
 
  Matrix( Scalar diagonalValue );

  Row& operator[]( int i ) { return m_v[i]; }

  const Row& operator[]( int i ) const { return m_v[i]; }

  // unary negation operator
  Matrix operator- ( void ) const;

  // addition
  Matrix operator+ ( const Matrix& B ) const;

  // subtraction
  Matrix operator- ( const Matrix& B ) const;

  // fill the NxN matrix of doubles with the current matrix values
  void FillRowMajor( double A[N*N] );

 private:

  DataMatrix m_v;
};


Matrix operator* ( const float& a, const Matrix& B );

Vector operator* ( const Vector& x, const Matrix& B );

// the open product of two vectors is a matrix
// (also known as the matrix product)
Matrix operator* ( const Vector& x, const Vector& y );

ostream& operator<< ( ostream& os, const Matrix& A );

#endif // #define __MATRIX_H
