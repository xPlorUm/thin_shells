// CVS ID
// $Id: test.cpp,v 1.1 2003/09/18 22:17:17 eitan Exp $

// AUTHOR
// Eitan Grinspun

// CONTACT
// email:eitan[at]cs[dot]caltech[dot]edu, email:eitan[at]cat[dot]nyu[dot]edu

// DESCRIPTION
// This file implements a test stub for the automatic differentiation code.

#include <iostream>
#include <math.h>

using namespace ::std;

#include "Matrix.h"
#include "Vector.h"
#include "Scalar.h"

#include "ConstScalar.h"
#include "ConstVector.h"
#include "DerScalar.h"
#include "DerVector.h"

void print( char* name, char* formula, const DerScalar& Ta ) {

	cout << name << " = " << formula << " = " << Ta.v() << endl;
	cout << "(D" << name << ") = ";
	cout << Ta.D();
	cout << endl << endl;;
}

void print( char* name, char* formula, const DerVector& Tx ) {

	cout << name << " = " << formula << " = ";
	cout << Tx.v();
	cout << endl;
	cout << "(D" << name << ") = " << endl;
	cout << Tx.D();
	cout << endl << endl;
}


DerVector Tx, Ty;

void Compute( char *x ) {

	cout << "Computing derivatives w.r.t. " << x << endl;
	cout << "----------------------------------" << endl << endl;

	DerVector Tz;
	DerScalar Ta, Tb, Tc;

	Tx.v() = Vector(1,2);  // x dot x = 5
	Ty.v() = Vector(2,3); // x dot y = 13

	print( "x", "x", Tx );
	print( "y", "y", Ty );

	Ta = Tx.Dot( Ty );
	print( "a", "x dot y", Ta );

	Tb = Tx.Dot( Tx );
	print( "b", "x dot x", Tb );

	Tc = Ta + Tb;
	print( "c", "a + b", Tc );

	Tc = Ta - Tb;
	print( "c", "a - b", Tc );

	Tc = Ta * Tb;
	print( "c", "a * b", Tc );

	Tc = Tx.Length();
	print( "c", "||x||", Tc );

	Tz = Ta * Tx;
	print( "z", "a * x", Tz );

	ConstScalar two(2);
	Tz = Tx + two * Ty;
	print( "z", "x + 2y", Tz );
}



int main(int argc, char* argv[])
{
	Tx.D() = Matrix::Identity;
	Ty.D() = Matrix::Zero;

	Compute( "x" );

	Ty.D() = Matrix::Identity;
	Tx.D() = Matrix::Zero;

	Compute( "y" );
}
