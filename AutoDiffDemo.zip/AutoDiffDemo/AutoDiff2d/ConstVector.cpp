// CVS ID
// $Id: ConstVector.cpp,v 1.3 2003/09/18 20:11:52 eitan Exp $

// AUTHOR
// Eitan Grinspun

// CONTACT
// email:eitan[at]cs[dot]caltech[dot]edu, email:eitan[at]cat[dot]nyu[dot]edu

// DESCRIPTION
// This file implements the class ConstVector. This class represents vectors
// that are independent variables, ie, such vectors need not carry
// derivative information, as their derivative w.r.t. any other independent
// variable is 0.

#include "Vector.h"
#include "Scalar.h"

#include "ConstScalar.h"
#include "ConstVector.h"
#include "DerScalar.h"
#include "DerVector.h"

const ConstVector ConstVector::Zero( Vector::Zero);

ConstVector::ConstVector(void)
{
}

ConstVector::~ConstVector(void)
{
}

ConstVector::ConstVector( const Vector& v ) : m_v( v ) {
}


// computes the vector length
ConstScalar ConstVector::Length( void ) const {

  const Vector& x = v();

  return ConstScalar( x.Length());
}


// computes the vector negation
ConstVector ConstVector::operator- ( void ) const {

  const Vector& x = v();

  return ConstVector( -x );
}


// computes the vector-vector (vector-valued) sum
ConstVector ConstVector::operator+ ( const ConstVector& v2 ) const {

  const Vector& x1 = v();
  const Vector& x2 = v2.v();

  return ConstVector( x1 + x2 );
}

// computes the vector-vector sum and its derivative
DerVector ConstVector::operator+ ( const DerVector& Tv2 ) const {

  const Vector& x1 = v();
  const Vector& x2 = Tv2.v();
  const Matrix& D2 = Tv2.D();
 
  return DerVector( x1 + x2, D2);
}

// computes the vector-vector difference
ConstVector ConstVector::operator- ( const ConstVector& v2 ) const {

  const Vector& x1 = v();
  const Vector& x2 = v2.v();

  return ConstVector( x1 - x2 );
}


// computes the vector-vector difference and its derivative
DerVector ConstVector::operator- ( const DerVector& Tv2 ) const {

  const Vector& x1 = v();
  const Vector& x2 = Tv2.v();
  const Matrix& D2 = Tv2.D();
 
  return DerVector( x1 - x2, -D2);
}


// computes dot product
ConstScalar ConstVector::Dot( const ConstVector& v2 ) const {

  const Vector& x1 = v();
  const Vector& x2 = v2.v();

  return ConstScalar( x1. Dot( x2 ));
}


// computes the vector-vector (scalar-valued) dot product
// and its derivative
// uses chain rule: D(a.b) = a(Db) when a is constant, ie, (Da)=0
DerScalar ConstVector::Dot( const DerVector& Tv2 ) const {

  const Vector& x1 = v();
  const Vector& x2 = Tv2.v();
  const Matrix& D2 = Tv2.D();

  return DerScalar( x1. Dot( x2), x1 * D2 );
}


// division by constant scalar
ConstVector ConstVector::operator /( const ConstScalar& Ca ) {

  const Vector& x = v();
  const Scalar& a = Ca.v();

  return ConstVector( x / a );
}


// Alternative notation for addition
void ConstVector::operator +=( const ConstVector& v2 ) {

  (*this) = (*this) + v2;
}



#if 0
// computes cross product
ConstVector ConstVector::Cross( const ConstVector& v2 ) const {

  const Vector& x1 = v();
  const Vector& x2 = v2.v();

  return ConstVector( x1. Cross( x2 ));
}


// computes the vector-vector (vector-valued) cross product
// and its derivative
// uses chain rule: D(a x b) = D2(a x b)(Db), a is a constant, (Da)=0
DerVector ConstVector::Cross( const DerVector& Tv2 ) const {

  const Vector& x1 = v();
  const Vector& x2 = Tv2.v();
  const Matrix& D2 = Tv2.D();

  return DerVector( x1. Cross( x2 ), DiffCross2(x1,x2) * D2);
}
#endif
